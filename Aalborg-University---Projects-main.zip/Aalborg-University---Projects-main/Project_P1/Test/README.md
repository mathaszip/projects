Link til noter omkring unit testing

- https://silken-shark-cf6.notion.site/Unit-testing-650632e2cd3741fcb0b5a2c5e2eb194f
