#ifndef P1_PROTOTYPE_MENU_H
#define P1_PROTOTYPE_MENU_H

#endif //P1_PROTOTYPE_MENU_H

//store struct

void initial_screen();